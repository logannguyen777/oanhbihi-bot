export function ScrollArea({ children }) {
    return <div className="overflow-y-auto max-h-80">{children}</div>;
  }
  