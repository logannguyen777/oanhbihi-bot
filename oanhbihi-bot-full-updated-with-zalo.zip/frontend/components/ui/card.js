export function Card({ children }) {
    return <div className="p-4 bg-gray-200 rounded-md shadow">{children}</div>;
  }
  