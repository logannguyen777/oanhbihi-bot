export function Toast({ msg }) {
    return (
      <div className="toast toast-top toast-end z-50">
        <div className="alert alert-success">
          <span>{msg}</span>
        </div>
      </div>
    );
  }
  