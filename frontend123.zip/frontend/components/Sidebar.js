import Link from "next/link";
import { useRouter } from "next/router";
import { ROUTES } from "@/lib/routes";

export default function Sidebar() {
  const router = useRouter();

  return (
    <div className="w-64 h-full bg-purple-100 p-4">
      <h2 className="text-xl font-bold text-purple-700 mb-6">🎀 Oanh Bihi</h2>
      <ul className="space-y-2">
        {ROUTES.map((r) => (
          <li key={r.path}>
            <Link href={r.path}>
              <span
                className={`block px-3 py-2 rounded cursor-pointer ${
                  router.pathname === r.path
                    ? "bg-purple-500 text-white"
                    : "hover:bg-purple-200"
                }`}
              >
                {r.label}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
