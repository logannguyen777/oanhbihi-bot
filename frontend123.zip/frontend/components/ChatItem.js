export default function ChatItem({ role, text }) {
    const isUser = role === "user";
    return (
      <div className={`mb-3 ${isUser ? "text-right" : "text-left"}`}>
        <div
          className={`inline-block px-4 py-2 rounded-lg ${
            isUser ? "bg-purple-200" : "bg-gray-100"
          }`}
        >
          {text}
        </div>
      </div>
    );
  }
  