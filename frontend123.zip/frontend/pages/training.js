import Layout from "@/components/Layout";
import { useState } from "react";
import { apiFetch } from "@/hooks/useApi";

export default function TrainingPage() {
  const [urls, setUrls] = useState(["https://fta.dainam.edu.vn"]);
  const [fileTypes, setFileTypes] = useState(["pdf", "docx"]);
  const [schedule, setSchedule] = useState("0 0 * * *");
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleFileUpload = async () => {
    const formData = new FormData();
    files.forEach((file) => formData.append("files", file));

    setLoading(true);
    await fetch("/api/train/upload", {
      method: "POST",
      body: formData,
    });
    setLoading(false);
    alert("✅ Đã upload tài liệu!");
  };

  const handleCrawl = async () => {
    await apiFetch("/api/config/crawl", "POST", {
      urls,
      fileTypes,
      schedule,
    });
    alert("✅ Đã lưu config crawl!");
  };

  const startTraining = async () => {
    setLoading(true);
    await apiFetch("/api/train/start", "POST");
    setLoading(false);
    alert("✅ Đã khởi động huấn luyện!");
  };

  return (
    <Layout>
      <div className="max-w-3xl mx-auto p-6">
        <h2 className="text-2xl font-bold mb-4 text-purple-700">📚 Huấn luyện Oanh Bihi Bot</h2>

        {/* Upload */}
        <div className="bg-white p-4 shadow rounded mb-6">
          <h3 className="font-semibold text-lg mb-2">📤 Upload tài liệu</h3>
          <input
            type="file"
            multiple
            className="file-input file-input-bordered w-full"
            onChange={(e) => setFiles(Array.from(e.target.files))}
          />
          <button className="btn btn-primary mt-3" onClick={handleFileUpload} disabled={loading}>
            Tải lên
          </button>
        </div>

        {/* Crawl */}
        <div className="bg-white p-4 shadow rounded mb-6">
          <h3 className="font-semibold text-lg mb-2">🌐 Crawl từ website</h3>
          <label className="label">Danh sách URL</label>
          <textarea
            className="textarea textarea-bordered w-full mb-2"
            rows={3}
            value={urls.join("\n")}
            onChange={(e) => setUrls(e.target.value.split("\n"))}
          />
          <label className="label">Loại file (pdf, docx...)</label>
          <input
            className="input input-bordered w-full mb-2"
            value={fileTypes.join(",")}
            onChange={(e) => setFileTypes(e.target.value.split(","))}
          />
          <label className="label">Schedule (cron)</label>
          <input
            className="input input-bordered w-full mb-3"
            value={schedule}
            onChange={(e) => setSchedule(e.target.value)}
          />
          <button className="btn btn-secondary" onClick={handleCrawl}>
            Cấu hình crawl
          </button>
        </div>

        {/* Training */}
        <div className="bg-white p-4 shadow rounded">
          <h3 className="font-semibold text-lg mb-2">🧠 Huấn luyện lại</h3>
          <button className="btn btn-accent" onClick={startTraining} disabled={loading}>
            Bắt đầu train lại bot
          </button>
        </div>
      </div>
    </Layout>
  );
}
