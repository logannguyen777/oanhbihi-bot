import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import { apiFetch } from "@/hooks/useApi";

export default function AdminChat() {
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [conversation, setConversation] = useState([]);
  const [reply, setReply] = useState("");

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    const res = await apiFetch("/api/admin/conversations");
    setUsers(res.users || []);
  };

  const loadConversation = async (userId) => {
    const res = await apiFetch(`/api/admin/conversations/${userId}`);
    setSelectedUser(res.user_id);
    setConversation(res.conversation);
  };

  const toggleBot = async (userId) => {
    await apiFetch("/api/admin/toggle-bot", "POST", { user_id: userId });
    fetchUsers(); // refresh status
  };

  const sendReply = async () => {
    if (!reply.trim() || !selectedUser) return;
    await apiFetch("/api/admin/reply", "POST", {
      user_id: selectedUser,
      message: reply,
    });
    setReply("");
    loadConversation(selectedUser);
  };

  return (
    <Layout>
      <div className="grid grid-cols-3 gap-6 p-6">
        {/* Danh sách người dùng */}
        <div className="col-span-1 bg-white shadow rounded p-4 overflow-y-auto h-[70vh]">
          <h3 className="font-bold text-purple-700 mb-3">📒 Hội thoại gần đây</h3>
          {users.map((user) => (
            <div
              key={user.id}
              className="p-2 border-b cursor-pointer hover:bg-purple-50 rounded"
              onClick={() => loadConversation(user.id)}
            >
              <div className="font-semibold">{user.name}</div>
              <div className="text-sm text-gray-500 line-clamp-1">
                {user.lastMessage}
              </div>
              <div className="text-xs text-gray-400">Kênh: {user.channel}</div>
              <div className="text-xs">
                Bot:{" "}
                <span className={`font-bold ${user.botEnabled ? "text-green-600" : "text-red-500"}`}>
                  {user.botEnabled ? "Bật" : "Tắt"}
                </span>{" "}
                | Tin chưa đọc: {user.unread}
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleBot(user.id);
                }}
                className="btn btn-xs btn-outline mt-1"
              >
                {user.botEnabled ? "Tắt bot" : "Bật bot"}
              </button>
            </div>
          ))}
        </div>

        {/* Hiển thị cuộc hội thoại */}
        <div className="col-span-2 bg-white shadow rounded p-4 flex flex-col">
          <h3 className="font-bold text-purple-700 mb-2">💬 Chi tiết hội thoại</h3>
          <div className="flex-1 overflow-y-auto mb-3 border rounded p-2 h-[50vh]">
            {conversation.map((msg, idx) => (
              <div
                key={idx}
                className={`mb-2 text-sm ${
                  msg.role === "user" ? "text-gray-800" : "text-blue-600 font-semibold"
                }`}
              >
                <span className="block">
                  [{msg.timestamp.split("T")[0]}] {msg.role.toUpperCase()}:
                </span>
                <span className="block ml-2">{msg.message}</span>
              </div>
            ))}
          </div>

          {/* Nhập phản hồi */}
          {selectedUser && (
            <div className="flex gap-2">
              <input
                className="input input-bordered flex-1"
                value={reply}
                onChange={(e) => setReply(e.target.value)}
                placeholder="Nhập phản hồi tới sinh viên..."
              />
              <button className="btn btn-primary" onClick={sendReply}>
                Gửi
              </button>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
