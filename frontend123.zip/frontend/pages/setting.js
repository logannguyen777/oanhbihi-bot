import Layout from "@/components/Layout";
import { useState } from "react";
import { apiFetch } from "@/hooks/useApi";

export default function Settings() {
  const [openaiKey, setOpenaiKey] = useState("");
  const [pageToken, setPageToken] = useState("");
  const [verifyToken, setVerifyToken] = useState("");
  const [zaloToken, setZaloToken] = useState("");
  const [zaloVerify, setZaloVerify] = useState("");
  const [persona, setPersona] = useState({
    name: "Oanh Bihi",
    age: "18",
    gender: "female",
    tone: "nhí nhảnh, dễ thương",
    greeting: "Chào anh/chị, em là Oanh Bihi nè 💜",
    style: "anime girl xinh xắn",
  });

  const saveMessenger = async () => {
    await apiFetch("/api/config/messenger", "POST", {
      pageToken,
      verifyToken,
    });
    alert("✅ Đã lưu cấu hình Messenger");
  };

  const saveZalo = async () => {
    await apiFetch("/api/config/zalo", "POST", {
      accessToken: zaloToken,
      verifyToken: zaloVerify,
    });
    alert("✅ Đã lưu cấu hình Zalo");
  };

  const savePersona = async () => {
    await apiFetch("/api/config/persona", "POST", persona);
    alert("✅ Đã lưu persona Oanh Bihi");
  };

  return (
    <Layout>
      <div className="max-w-3xl mx-auto p-6">
        <h2 className="text-2xl font-bold mb-4 text-purple-700">⚙️ Cấu hình hệ thống</h2>

        <div className="bg-white p-4 shadow rounded mb-6">
          <h3 className="font-semibold text-lg mb-2">🔑 OpenAI API Key</h3>
          <input
            className="input input-bordered w-full"
            value={openaiKey}
            onChange={(e) => setOpenaiKey(e.target.value)}
            placeholder="sk-xxx..."
          />
        </div>

        <div className="bg-white p-4 shadow rounded mb-6">
          <h3 className="font-semibold text-lg mb-2">📘 Messenger Config</h3>
          <input
            className="input input-bordered w-full mb-2"
            placeholder="Page Token"
            value={pageToken}
            onChange={(e) => setPageToken(e.target.value)}
          />
          <input
            className="input input-bordered w-full mb-2"
            placeholder="Verify Token"
            value={verifyToken}
            onChange={(e) => setVerifyToken(e.target.value)}
          />
          <button className="btn btn-primary" onClick={saveMessenger}>
            Lưu Messenger
          </button>
        </div>

        <div className="bg-white p-4 shadow rounded mb-6">
          <h3 className="font-semibold text-lg mb-2">💬 Zalo Config</h3>
          <input
            className="input input-bordered w-full mb-2"
            placeholder="Access Token"
            value={zaloToken}
            onChange={(e) => setZaloToken(e.target.value)}
          />
          <input
            className="input input-bordered w-full mb-2"
            placeholder="Verify Token"
            value={zaloVerify}
            onChange={(e) => setZaloVerify(e.target.value)}
          />
          <button className="btn btn-primary" onClick={saveZalo}>
            Lưu Zalo
          </button>
        </div>

        <div className="bg-white p-4 shadow rounded">
          <h3 className="font-semibold text-lg mb-2">🎀 Oanh Bihi - Persona</h3>
          <div className="grid grid-cols-2 gap-3">
            {Object.keys(persona).map((key) => (
              <input
                key={key}
                className="input input-bordered w-full"
                placeholder={key}
                value={persona[key]}
                onChange={(e) => setPersona({ ...persona, [key]: e.target.value })}
              />
            ))}
          </div>
          <button className="btn btn-secondary mt-4" onClick={savePersona}>
            Lưu Persona
          </button>
        </div>
      </div>
    </Layout>
  );
}
