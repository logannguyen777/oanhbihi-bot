import Layout from "@/components/Layout";
import AuthGuard from "@/components/AuthGuard";
import { useEffect, useState } from "react";

export default function AdminChat() {
  const [users, setUsers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [conversation, setConversation] = useState([]);
  const [reply, setReply] = useState("");

  useEffect(() => {
    fetch("/api/admin/conversations")
      .then((res) => res.json())
      .then((data) => setUsers(data.users));
  }, []);

  const loadConversation = (userId) => {
    setSelected(userId);
    fetch(`/api/admin/conversations/${userId}`)
      .then((res) => res.json())
      .then((data) => setConversation(data.conversation));
  };

  const sendReply = async () => {
    if (!reply.trim()) return;
    await fetch("/api/admin/reply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: selected, message: reply }),
    });
    setReply("");
    loadConversation(selected);
  };

  const toggleBot = async (userId) => {
    await fetch("/api/admin/toggle-bot", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: userId }),
    });
    const updated = await fetch("/api/admin/conversations").then((res) => res.json());
    setUsers(updated.users);
  };

  return (
    <AuthGuard>
      <Layout>
        <div className="text-2xl font-bold mb-4">💼 Quản lý hội thoại</div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            {users.map((u) => (
              <div
                key={u.id}
                className={`card shadow p-3 cursor-pointer ${
                  u.id === selected ? "bg-primary text-white" : "bg-base-100"
                }`}
                onClick={() => loadConversation(u.id)}
              >
                <div className="font-bold">{u.name}</div>
                <div className="text-sm">{u.lastMessage}</div>
                <div className="text-xs">
                  Bot: {u.botEnabled ? "✅ Bật" : "❌ Tắt"} | Chưa đọc: {u.unread}
                </div>
                <button
                  className="btn btn-xs btn-outline mt-2"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleBot(u.id);
                  }}
                >
                  Toggle Bot
                </button>
              </div>
            ))}
          </div>

          <div className="col-span-2">
            <div className="bg-base-200 p-4 rounded h-[60vh] overflow-y-auto mb-4">
              {conversation.map((msg) => (
                <div
                  key={msg.id}
                  className={`chat ${
                    msg.role === "user"
                      ? "chat-start"
                      : msg.role === "bot"
                      ? "chat-end"
                      : "chat-end"
                  }`}
                >
                  <div className="chat-header text-sm">
                    {msg.role === "user"
                      ? "🎓 Người dùng"
                      : msg.role === "bot"
                      ? "🤖 Bot"
                      : "👨‍🏫 Admin"}
                  </div>
                  <div className="chat-bubble">{msg.message}</div>
                </div>
              ))}
            </div>

            {selected && (
              <div>
                <textarea
                  className="textarea textarea-bordered w-full"
                  placeholder="Phản hồi..."
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                ></textarea>
                <button onClick={sendReply} className="btn btn-primary mt-2 float-right">
                  Gửi phản hồi
                </button>
              </div>
            )}
          </div>
        </div>
      </Layout>
    </AuthGuard>
  );
}