import Layout from "@/components/Layout";
import AuthGuard from "@/components/AuthGuard";
import { useState } from "react";

export default function Settings() {
  const [openaiKey, setOpenaiKey] = useState("");
  const [fbPageToken, setFbPageToken] = useState("");
  const [fbVerifyToken, setFbVerifyToken] = useState("");
  const [zaloOAID, setZaloOAID] = useState("");
  const [zaloAccessToken, setZaloAccessToken] = useState("");
  const [zaloVerifyToken, setZaloVerifyToken] = useState("");
  const [message, setMessage] = useState("");

  const saveConfig = async () => {
    try {
      await fetch("/api/config/messenger", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pageToken: fbPageToken, verifyToken: fbVerifyToken }),
      });

      await fetch("/api/config/persona", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: "Oanh Bihi",
          age: "18",
          gender: "female",
          tone: "cute, supportive",
          greeting: "Xin chào! Em là Oanh Bihi 🩷",
          style: "anime, dịu dàng",
        }),
      });

      setMessage("✅ Đã lưu cấu hình thành công!");
    } catch (err) {
      setMessage("❌ Lỗi khi lưu cấu hình.");
    }
  };

  return (
    <AuthGuard>
      <Layout>
        <div className="text-xl font-bold mb-4">⚙️ Cấu hình hệ thống</div>

        <div className="grid gap-4 max-w-2xl">
          <input
            type="text"
            placeholder="🔑 OpenAI API Key"
            className="input input-bordered"
            value={openaiKey}
            onChange={(e) => setOpenaiKey(e.target.value)}
          />
          <input
            type="text"
            placeholder="📘 FB Page Token"
            className="input input-bordered"
            value={fbPageToken}
            onChange={(e) => setFbPageToken(e.target.value)}
          />
          <input
            type="text"
            placeholder="📘 FB Verify Token"
            className="input input-bordered"
            value={fbVerifyToken}
            onChange={(e) => setFbVerifyToken(e.target.value)}
          />
          <input
            type="text"
            placeholder="💬 Zalo OA ID"
            className="input input-bordered"
            value={zaloOAID}
            onChange={(e) => setZaloOAID(e.target.value)}
          />
          <input
            type="text"
            placeholder="🔐 Zalo Access Token"
            className="input input-bordered"
            value={zaloAccessToken}
            onChange={(e) => setZaloAccessToken(e.target.value)}
          />
          <input
            type="text"
            placeholder="🛡️ Zalo Verify Token"
            className="input input-bordered"
            value={zaloVerifyToken}
            onChange={(e) => setZaloVerifyToken(e.target.value)}
          />

          <button className="btn btn-primary" onClick={saveConfig}>
            💾 Lưu cấu hình
          </button>

          {message && <div className="text-sm mt-2">{message}</div>}
        </div>
      </Layout>
    </AuthGuard>
  );
}