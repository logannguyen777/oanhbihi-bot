import Layout from "@/components/Layout";
import AuthGuard from "@/components/AuthGuard";
import { useState } from "react";

export default function Dashboard() {
  const [tab, setTab] = useState("overview");

  return (
    <AuthGuard>
      <Layout>
        <div className="text-2xl font-semibold mb-4">📊 Tổng quan hệ thống</div>
        <div role="tablist" className="tabs tabs-bordered mb-4">
          <a
            role="tab"
            className={`tab ${tab === "overview" ? "tab-active" : ""}`}
            onClick={() => setTab("overview")}
          >
            Tổng quan
          </a>
          <a
            role="tab"
            className={`tab ${tab === "config" ? "tab-active" : ""}`}
            onClick={() => setTab("config")}
          >
            Cấu hình
          </a>
          <a
            role="tab"
            className={`tab ${tab === "training" ? "tab-active" : ""}`}
            onClick={() => setTab("training")}
          >
            Training
          </a>
        </div>

        {tab === "overview" && (
          <div className="space-y-2">
            <div className="alert alert-info">✅ Bot đang hoạt động bình thường</div>
            <div className="card bg-base-200 shadow p-4">
              <h3 className="font-bold text-lg mb-1">📈 Trạng thái hoạt động</h3>
              <p>Bot đã trả lời hơn <strong>1,000</strong> tin nhắn!</p>
            </div>
          </div>
        )}

        {tab === "config" && (
          <div className="card bg-base-200 shadow p-4">
            <h3 className="font-bold text-lg mb-2">⚙️ Cấu hình API</h3>
            <p>Đi tới <a href="/settings" className="link link-primary">Trang cấu hình</a> để chỉnh sửa.</p>
          </div>
        )}

        {tab === "training" && (
          <div className="card bg-base-200 shadow p-4">
            <h3 className="font-bold text-lg mb-2">🤖 Training dữ liệu</h3>
            <p>Đi tới <a href="/settings" className="link link-primary">Trang cấu hình</a> để train lại bot.</p>
          </div>
        )}
      </Layout>
    </AuthGuard>
  );
}