import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import Head from "next/head";

export default function Login() {
  const { login } = useAuth();
  const [form, setForm] = useState({ username: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (res.ok && data.token) {
        login(data.token);
      } else {
        setError(data.detail || "Sai tài khoản hoặc mật khẩu");
      }
    } catch (err) {
      setError("Lỗi kết nối server");
    }
    setLoading(false);
  };

  return (
    <>
      <Head>
        <title>Đăng nhập - Oanh Bihi Bot</title>
      </Head>
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-purple-100 to-pink-100">
        <div className="card w-96 bg-base-100 shadow-xl">
          <div className="card-body">
            <h2 className="card-title justify-center text-2xl font-bold">🎀 Oanh Bihi Bot</h2>
            <form onSubmit={handleLogin} className="flex flex-col gap-4">
              <input
                name="username"
                type="text"
                placeholder="Tên đăng nhập"
                className="input input-bordered w-full"
                value={form.username}
                onChange={handleChange}
                required
              />
              <input
                name="password"
                type="password"
                placeholder="Mật khẩu"
                className="input input-bordered w-full"
                value={form.password}
                onChange={handleChange}
                required
              />
              {error && <div className="text-red-500">{error}</div>}
              <button
                type="submit"
                className={`btn btn-primary w-full ${loading ? "loading" : ""}`}
              >
                Đăng nhập
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}