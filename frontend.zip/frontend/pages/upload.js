import Layout from "@/components/Layout";
import AuthGuard from "@/components/AuthGuard";
import { useState } from "react";

export default function Upload() {
  const [files, setFiles] = useState([]);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const handleUpload = async () => {
    if (!files.length) return;

    const formData = new FormData();
    for (let f of files) {
      formData.append("files", f);
    }

    setLoading(true);
    setMessage("📤 Đang tải lên và xử lý tài liệu...");

    try {
      const res = await fetch("/api/train/upload", {
        method: "POST",
        body: formData,
      });
      if (res.ok) {
        setMessage("✅ Tải lên thành công! Bot sẽ tự động embedding.");
      } else {
        setMessage("⚠️ Tải lên thất bại.");
      }
    } catch (err) {
      setMessage("❌ Lỗi không xác định khi tải lên.");
    }

    setLoading(false);
  };

  return (
    <AuthGuard>
      <Layout>
        <div className="text-2xl font-bold mb-4">📁 Tải lên tài liệu đào tạo bot</div>

        <input
          type="file"
          className="file-input file-input-bordered w-full max-w-md"
          multiple
          onChange={(e) => setFiles([...e.target.files])}
        />

        <button className={`btn btn-primary mt-4 ${loading && "loading"}`} onClick={handleUpload}>
          Gửi file huấn luyện
        </button>

        {message && <div className="mt-4 text-sm">{message}</div>}
      </Layout>
    </AuthGuard>
  );
}