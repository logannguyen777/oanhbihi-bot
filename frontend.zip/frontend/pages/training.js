import Layout from "@/components/Layout";
import AuthGuard from "@/components/AuthGuard";
import { useState } from "react";

export default function Training() {
  const [status, setStatus] = useState("");
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);

  const handleCrawl = async () => {
    if (!url) {
      setStatus("⚠️ Vui lòng nhập URL trước khi crawl nha!");
      return;
    }

    setLoading(true);
    setStatus("🔍 Đang crawl dữ liệu từ website...");

    try {
      const res = await fetch("/api/config/crawl", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          urls: [url],
          fileTypes: ["html"], // 🧠 đúng tên field trong schema
          schedule: "manual",
        }),
      });

      if (!res.ok) throw new Error("Crawl failed");
      setStatus("✅ Đã crawl dữ liệu thành công!");
    } catch (err) {
      console.error("Crawl Error:", err);
      setStatus("⚠️ Lỗi khi crawl dữ liệu. Vui lòng kiểm tra URL hoặc thử lại sau.");
    }

    setLoading(false);
  };

  const handleTrain = async () => {
    setLoading(true);
    setStatus("🤖 Đang huấn luyện embedding...");

    try {
      const res = await fetch("/api/train/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      if (!res.ok) throw new Error("Training failed");
      setStatus("✅ Huấn luyện hoàn tất!");
    } catch (err) {
      console.error("Train Error:", err);
      setStatus("⚠️ Lỗi khi huấn luyện dữ liệu.");
    }

    setLoading(false);
  };

  return (
    <AuthGuard>
      <Layout>
        <div className="text-2xl font-bold mb-4">📚 Huấn luyện & Crawl dữ liệu</div>

        <div className="form-control mb-4">
          <label className="label font-bold">🌐 URL Website muốn Crawl</label>
          <input
            className="input input-bordered"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://fta.dainam.edu.vn"
          />
        </div>

        <div className="flex gap-4">
          <button
            onClick={handleCrawl}
            className={`btn btn-outline ${loading ? "loading" : ""}`}
            disabled={loading}
          >
            Crawl Dữ Liệu
          </button>
          <button
            onClick={handleTrain}
            className={`btn btn-primary ${loading ? "loading" : ""}`}
            disabled={loading}
          >
            Huấn luyện bot
          </button>
        </div>

        <div className="mt-4 text-sm">{status}</div>
      </Layout>
    </AuthGuard>
  );
}
