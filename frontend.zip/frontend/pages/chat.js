import Layout from "@/components/Layout";
import AuthGuard from "@/components/AuthGuard";
import { useState, useRef, useEffect } from "react";

export default function ChatPage() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [typing, setTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, typing]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = {
      role: "user",
      content: input,
    };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setTyping(true);

    try {
      const res = await fetch("/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ input_text: input }),
      });
      const data = await res.json();
      if (data.response) {
        const botMessage = {
          role: "assistant",
          content: data.response,
        };
        setMessages((prev) => [...prev, botMessage]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "⚠️ Lỗi khi gửi yêu cầu tới bot." },
      ]);
    }
    setTyping(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <AuthGuard>
      <Layout>
        <div className="text-xl font-semibold mb-2">💬 Chat với Oanh Bihi</div>
        <div className="chat-box bg-base-200 p-4 rounded h-[70vh] overflow-y-auto">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`chat ${msg.role === "user" ? "chat-end" : "chat-start"}`}
            >
              <div className="chat-image avatar">
                <div className="w-10 rounded-full">
                  <img
                    src={
                      msg.role === "user"
                        ? "https://api.dicebear.com/6.x/thumbs/svg?seed=User"
                        : "https://api.dicebear.com/6.x/bottts/svg?seed=OanhBihi"
                    }
                  />
                </div>
              </div>
              <div className="chat-bubble">{msg.content}</div>
            </div>
          ))}
          {typing && (
            <div className="chat chat-start">
              <div className="chat-image avatar">
                <div className="w-10 rounded-full">
                  <img src="https://api.dicebear.com/6.x/bottts/svg?seed=OanhBihi" />
                </div>
              </div>
              <div className="chat-bubble loading">Đang trả lời...</div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="mt-4">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="textarea textarea-bordered w-full"
            placeholder="Nhập nội dung..."
          ></textarea>
          <button onClick={handleSend} className="btn btn-primary mt-2 float-right">
            Gửi
          </button>
        </div>
      </Layout>
    </AuthGuard>
  );
}