export const sidebarRoutes = [
    {
      path: "/dashboard",
      label: "Dashboard",
      icon: "🏠",
    },
    {
      path: "/chat",
      label: "Chat",
      icon: "💬",
    },
    {
      path: "/settings",
      label: "Cấu hình",
      icon: "⚙️",
    },
    {
      path: "/admin_chat",
      label: "Admin Chat",
      icon: "👩‍💼",
    },
  ];