export default function ChatItem({ role, message }) {
    const isUser = role === "user";
    const isBot = role === "bot";
    const isAdmin = role === "admin";
  
    return (
      <div className={`chat ${isUser ? "chat-start" : "chat-end"}`}>
        <div className="chat-header text-sm mb-1">
          {isUser ? "🎓 User" : isBot ? "🤖 Bot" : "👨‍🏫 Admin"}
        </div>
        <div className="chat-bubble">{message}</div>
      </div>
    );
  }