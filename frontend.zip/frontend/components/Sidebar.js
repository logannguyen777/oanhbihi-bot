import Link from "next/link";
import { useRouter } from "next/router";
import { sidebarRoutes } from "@/lib/routes";

export default function Sidebar() {
  const router = useRouter();

  return (
    <aside className="w-64 h-screen bg-base-200 text-base-content">
      <div className="p-4 text-lg font-bold">Oanh Bihi 💜</div>
      <ul className="menu">
        {sidebarRoutes.map((route) => (
          <li key={route.path} className={router.pathname === route.path ? "bg-base-300 rounded" : ""}>
            <Link href={route.path} className="flex gap-2">
              <span>{route.icon}</span>
              {route.label}
            </Link>
          </li>
        ))}
      </ul>
    </aside>
  );
}