module.exports = {
    plugins: {
      tailwindcss: {},     // ✅ Dùng đúng plugin
      autoprefixer: {},
    },
  }
  